import pandas as pd
import numpy as np
import simulation_funs_DC as dc  
import warnings

warnings.filterwarnings('ignore')

design_para_d2d = [
    101325, # P_oa [2] 
    0.96,   # UPS_e [3]
    0.01,   # PD_lr [4] 
    0.01,   # L_percentage [5] 
    0.99,   # SHR [6] 
    20,     # delta_T_fluid [7] 
    30,     # Fan_Pressure_Min [8] 
    0.7,    # Fan_e_CRAC [9]
    200000, # Pump_Pressure_HD [10]
    0.6,    # Pump_e_HD [11]
    0.95,   # HTE [12] 
    10,     # delta_T_water [13]
    5,      # AT_CT [14]
    2,      # AT_HE [15]
    250000, # Pump_Pressure_D2D_Loop [16] 
    0.75,   # Pump_e_WE [17]
    200000, # Pump_Pressure_CW [18]
    0.7,    # Pump_e_CW [19]
    0.6,    # Chiller_load [20]
    5,      # delta_T_CT [21]
    150000, # Pump_Pressure_CT [22]
    0.7,    # Pump_e_CT [23]
    0.001,  # Windage_p [24]
    3,      # CC [25]
    1.2,    # LGRatio [26]
    200,    # Fan_Pressure_CT [27]
    0.7,    # Fan_e_CT [28]
    45,     # T_up [29] - 
    30,     # T_lw [30] -
    15,     # dp_up [31]
    5,      # dp_lw [32]
    60,     # RH_up [33]
    20,     # RH_lw [34]
    0.05    # pcop [35]
]

file_path = 'EU_33_Countries.xlsx'
df_temp = pd.read_excel(file_path, sheet_name='Tem')
df_rh = pd.read_excel(file_path, sheet_name='RH')

regions = [col.replace('_Temp', '').strip() for col in df_temp.columns if col.endswith('_Temp')]
final_results = pd.DataFrame()

for reg in regions:
    print(f"Calculating D2D for: {reg}...")
    p_list, w_list = [], []
    t_col, r_col = f"{reg}_Temp", f"{reg}_RH"
    
    for i in range(len(df_temp)):
        T = df_temp[t_col].iloc[i]
        RH = df_rh[r_col].iloc[i]
        
        if pd.isna(T) or pd.isna(RH):
            p_list.append(np.nan)
            w_list.append(np.nan)
        else:
            try:
                w_input = [T, RH] + design_para_d2d
                
                res = dc.PUE_WUE_D2D_LiquidCooling(w_input)
                
                p_list.append(res[0])
                w_list.append(res[1])
            except Exception:
                p_list.append(np.nan)
                w_list.append(np.nan)
    
    final_results[f"{reg}_PUE_D2D"] = p_list
    final_results[f"{reg}_WUE_D2D"] = w_list

output_name = 'UK_Final_Result_D2D.xlsx'
final_results.to_excel(output_name, index=False)
print(f"Done! {output_name}.")