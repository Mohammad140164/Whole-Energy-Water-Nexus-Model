import pandas as pd
import numpy as np
import simulation_funs_DC as dc
import warnings

warnings.filterwarnings('ignore')

design_para_ae = [
    101325, # P_oa [2]
    0.95,   # UPS_e [3]
    0.02,   # PD_lr [4]
    0.01,   # L_percentage [5]
    10,     # delta_T_air [6]
    300,    # Fan_Pressure_CRAC [7]
    0.7,    # Fan_e_CRAC [8]
    200000, # Pump_Pressure_HD [9]
    0.6,    # Pump_e_HD [10]
    5,      # AT_CT [11]
    0.6,    # Chiller_load [12]
    10,     # delta_T_water [13]
    200000, # Pump_Pressure_CW [14]
    0.7,    # Pump_e_CW [15]
    5,      # delta_T_CT [16]
    150000, # Pump_Pressure_CT [17]
    0.7,    # Pump_e_CT [18]
    0.001,  # Windage_p [19]
    3,      # CC [20]
    200,    # Fan_Pressure_CT [21]
    0.7,    # Fan_e_CT [22]
    0.9,    # SHR [23]
    1.2,    # LGRatio [24]
    27,     # T_up [25]
    18,     # T_lw [26]
    15,     # dp_up [27]
    5,      # dp_lw [28]
    60,     # RH_up [29]
    20,     # RH_lw [30]
    0.05    # pcop [31]
]

file_path = 'UK_13_Regions.xlsx'
import os

print(os.getcwd())

df_temp = pd.read_excel(file_path, sheet_name='Tem')
df_rh = pd.read_excel(file_path, sheet_name='RH')

regions = [col.replace('_Temp', '').strip() for col in df_temp.columns if col.endswith('_Temp')]
final_results = pd.DataFrame()

for reg in regions:
    print(f"Calculation Air-side Economizer for: {reg}...")
    p_list, w_list = [], []
    t_col, r_col = f"{reg}_Temp", f"{reg}_RH"
    
    for i in range(len(df_temp)):
        T = df_temp[t_col].iloc[i]
        RH = df_rh[r_col].iloc[i]
        
        if pd.isna(T) or pd.isna(RH):
            p_list.append(np.nan); w_list.append(np.nan)
        else:
            try:
                w_input = [T, RH] + design_para_ae
                
                res = dc.PUE_WUE_AE_Chiller(w_input)
                
                p_list.append(res[0])
                w_list.append(res[1])
            except Exception as e:
                p_list.append(np.nan); w_list.append(np.nan)
    
    final_results[f"{reg}_PUE"] = p_list
    final_results[f"{reg}_WUE"] = w_list

final_results.to_excel('UK_Result_AE_Chiller.xlsx', index=False)
